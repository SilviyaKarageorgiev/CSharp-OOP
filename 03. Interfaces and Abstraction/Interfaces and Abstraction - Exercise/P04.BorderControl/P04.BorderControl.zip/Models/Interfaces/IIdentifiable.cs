﻿namespace P04.BorderControl.Models.Interfaces
{
    public interface IIdentifiable
    {

        string Id { get; }

    }
}
