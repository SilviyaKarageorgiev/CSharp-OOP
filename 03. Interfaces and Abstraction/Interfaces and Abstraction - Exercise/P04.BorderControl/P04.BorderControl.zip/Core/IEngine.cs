﻿namespace P04.BorderControl.Core
{
    public interface IEngine
    {

        void Start();

    }
}
