﻿namespace P06.FoodShortage.Core
{
    public interface IEngine
    {
        void Start();
    }
}
