﻿namespace P05.BirthdayCelebrations.Core
{
    public interface IEngine
    {
        void Start();
    }
}
