﻿namespace P05.BirthdayCelebrations.Models.Interfaces
{
    public interface IBirthable
    {

        string Birthdate { get; }

    }
}
