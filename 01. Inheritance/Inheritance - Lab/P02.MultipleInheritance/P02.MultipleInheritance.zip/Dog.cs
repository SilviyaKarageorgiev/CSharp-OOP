﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P02.MultipleInheritance
{
    public class Dog :Animal
    {

        public void Bark()
        {
            Console.WriteLine("barking...");
        }

    }
}
