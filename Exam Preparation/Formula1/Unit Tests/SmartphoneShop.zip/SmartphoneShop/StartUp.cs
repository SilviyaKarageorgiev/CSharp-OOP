﻿namespace SmartphoneShop
{
    public class StartUp
    {
        static void Main()
        {
        }
    }
}
