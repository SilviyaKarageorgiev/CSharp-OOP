﻿namespace Heroes.Models.Heroes
{
    public class Knight : Hero
    {
        public Knight(string name, int health, int armour)
            : base(name, health, armour)
        {
        }
    }
}
