﻿using Heroes.Models.Contracts;
using System.Collections.Generic;

namespace Heroes.Models.Map
{
    public class Map : IMap
    {
        public string Fight(ICollection<IHero> players)
        {
            throw new System.NotImplementedException();
        }
    }
}
