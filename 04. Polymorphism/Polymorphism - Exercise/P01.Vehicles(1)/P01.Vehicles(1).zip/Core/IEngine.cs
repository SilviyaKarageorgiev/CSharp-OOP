﻿namespace P01.Vehicles_1_.Core
{
    public interface IEngine
    {
        void Start();
    }
}
